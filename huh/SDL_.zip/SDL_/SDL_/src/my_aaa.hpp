

#ifndef MY_AAA
#define MY_AAA

#include "my_sdl_app.hpp"

struct my_aaa
{
	my_sdl_app* app = nullptr;

	my_aaa()
	{
		app = new my_sdl_app("demo", 640, 360, 60.0f);
	}

	~my_aaa()
	{
		delete app;
		app = nullptr;
	}

	bool Update()
	{
		app->Update();

		// here

		SDL_RenderPresent(app->renderer);

		return app->active;
	}
};

#endif

