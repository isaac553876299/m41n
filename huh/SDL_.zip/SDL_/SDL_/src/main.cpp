

#include "my_aaa.hpp"

int main(int argc, char** argv)
{
	my_aaa* game = new my_aaa;

	while (game->Update());

	delete game;
	game = nullptr;

	return 0;
}

