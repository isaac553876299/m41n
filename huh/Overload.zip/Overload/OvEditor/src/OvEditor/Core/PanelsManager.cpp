/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvEditor/Core/PanelsManager.h"

OvEditor::Core::PanelsManager::PanelsManager(OvUI::Modules::Canvas & p_canvas) : m_canvas(p_canvas)
{
}
