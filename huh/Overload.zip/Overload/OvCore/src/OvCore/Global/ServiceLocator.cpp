/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvCore/Global/ServiceLocator.h"

std::unordered_map<size_t, std::any> OvCore::Global::ServiceLocator::__SERVICES;

