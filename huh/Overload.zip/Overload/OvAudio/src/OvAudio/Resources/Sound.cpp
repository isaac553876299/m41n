/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvAudio/Resources/Sound.h"

OvAudio::Resources::Sound::Sound(const std::string& p_path) : path(p_path)
{
}
