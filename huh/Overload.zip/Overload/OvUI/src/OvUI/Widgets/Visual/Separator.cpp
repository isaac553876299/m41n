/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvUI/Widgets/Visual/Separator.h"

void OvUI::Widgets::Visual::Separator::_Draw_Impl()
{
	ImGui::Separator();
}
