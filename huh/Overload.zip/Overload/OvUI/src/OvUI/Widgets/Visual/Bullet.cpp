/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvUI/Widgets/Visual/Bullet.h"

void OvUI::Widgets::Visual::Bullet::_Draw_Impl()
{
	ImGui::Bullet();
}
