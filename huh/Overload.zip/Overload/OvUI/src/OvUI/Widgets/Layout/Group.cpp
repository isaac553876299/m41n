/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvUI/Widgets/Layout/Group.h"

void OvUI::Widgets::Layout::Group::_Draw_Impl()
{
	DrawWidgets();
}
