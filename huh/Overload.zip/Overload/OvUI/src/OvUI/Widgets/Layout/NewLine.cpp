/**
* @project: Overload
* @author: Overload Tech.
* @licence: MIT
*/

#include "OvUI/Widgets/Layout/NewLine.h"

void OvUI::Widgets::Layout::NewLine::_Draw_Impl()
{
	ImGui::NewLine();
}
